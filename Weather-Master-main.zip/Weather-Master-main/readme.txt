Hey there!!!
Treat this file as readme for the "WEATHER+" webapp.
So soon there will be a seprate github repo for the same.
To view this website:
make sure the directory for the project:
1.npm init
2.npm install nodemon express body-parser bootstrap body
3.nodemon index.js
To view only the frontend of the project directly open the index.html
bootstarp is widely used here with all the assests in the assest folder.
Weather app uses openweather api with limit of 60 request per minute.
weather report page is targetted to blank.
entire project is responsive to any screen size.
visit this git repo
https://github.com/adityasuman990/Health-

